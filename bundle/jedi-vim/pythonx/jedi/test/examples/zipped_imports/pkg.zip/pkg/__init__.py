from . import module
from .module import value

pkg_init = 321
