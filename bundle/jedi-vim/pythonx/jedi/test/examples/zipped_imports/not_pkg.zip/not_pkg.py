value = 'single_file'
bla = 'not a package'
