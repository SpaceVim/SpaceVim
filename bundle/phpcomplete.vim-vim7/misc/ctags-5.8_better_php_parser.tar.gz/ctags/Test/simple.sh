#!/bin/sh

f1() {
}

function f2() {
}

function _a_b() {
}
