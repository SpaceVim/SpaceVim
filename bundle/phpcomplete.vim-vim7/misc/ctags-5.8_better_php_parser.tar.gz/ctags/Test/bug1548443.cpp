union TestUnion
{
int _number;
};

struct TestStruct
{
int _number;
};
