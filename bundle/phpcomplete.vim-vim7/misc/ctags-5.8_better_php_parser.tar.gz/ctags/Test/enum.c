enum test_enumeration {
    ENUM_1 = 1,
    ENUM_2,
    ENUM_3
};
