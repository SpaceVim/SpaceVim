var x = 1;
var z = {};
var y = [];

