#include <stdio.h>

#define ERROR_HAPPENED 50 
#define OK 2
#define NEXT_DEFINE 3

int main(int argc, char* argv[])
{
    printf("Hello world\n");
    return 0;
}

