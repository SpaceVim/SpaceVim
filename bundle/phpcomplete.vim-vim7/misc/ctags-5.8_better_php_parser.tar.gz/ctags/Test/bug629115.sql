/***/
DECLARE
   variable CLOB;
BEGIN
END;
