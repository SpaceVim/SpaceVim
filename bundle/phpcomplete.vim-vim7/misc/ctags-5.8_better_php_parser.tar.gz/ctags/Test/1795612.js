
// This file should generate the following tags:
//    classes
//      Test.RPC
//    methods
//      Test.RPC.asyncMethod
//      Test.RPC.asyncRequest
//    properties
//      Test.RPC.request_id
Test.RPC =
{
	request_id: 0,

	asyncRequest: function(
		/* string */	uri,
		/* object */	data,
		/* object */	callback)
	{
	},

	asyncMethod: function(
		/* string */	uri,
		/* string */	method,
		/* array */		params,
		/* object */	callback)
	{
	}
};

