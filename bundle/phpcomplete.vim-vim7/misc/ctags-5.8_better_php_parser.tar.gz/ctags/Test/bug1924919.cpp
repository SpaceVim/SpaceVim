#include <string>
namespace mud {
	std::string MajorVersion;
	std::string MinorVersion;
};
