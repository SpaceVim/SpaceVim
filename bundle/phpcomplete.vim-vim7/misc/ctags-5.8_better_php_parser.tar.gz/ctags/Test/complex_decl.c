/* Complex declarations */
static void (* const(ScanAction[5][5]))(void *)= {};
